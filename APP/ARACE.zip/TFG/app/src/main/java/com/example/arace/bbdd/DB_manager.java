package com.example.arace.bbdd;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DB_manager {
    /*
    private DB_Conexion db;
    private SQLiteDatabase _basededatos;
    public DB_manager(Context context){
        db=new DB_Conexion(context);

    }
    public DB_manager open() throws SQLException {
        _basededatos= db.getWritableDatabase();
        return this;
    }
    public void close(){

        db.close();
    }

     */
}
